﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
namespace Assets.Scripts
{
    public class AlertFeedSuperMooCow : GenericOneTimeAlert, IShowAlertFeedSuperMooCow
    {
        public AlertFeedSuperMooCow():base("ShownAlertFeedSuperMooCow")
        {

        }
    }
}