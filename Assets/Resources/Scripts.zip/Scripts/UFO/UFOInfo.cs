﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
namespace Assets.Scripts
{
    class UFOInfo
    {
        public Vector2 Position;
        public  UFOInfo(Vector2 position)
        {
            Position = position;
        }
    }
}
