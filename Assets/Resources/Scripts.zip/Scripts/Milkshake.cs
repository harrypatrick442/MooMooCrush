﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Assets.Scripts
{
	public abstract class Milkshake : FoodItem
	{
		
	}
}
