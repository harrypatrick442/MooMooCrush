﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

namespace Assets.Scripts
{
    public class LaserEyeController
    {
        public void SetInterface<T>(T o)
        {

        }
    }
}