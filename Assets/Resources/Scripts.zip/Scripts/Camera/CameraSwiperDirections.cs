﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;

namespace Assets.Scripts
{
    public enum CameraSwiperDirections { Horizontally, Vertically, All }
}