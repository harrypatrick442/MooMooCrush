﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
namespace Assets.Scripts
{
    public interface IMoosics
    {
        Moooooosic Spawn(Vector2 from, Vector2 to, float speed);
    }
}