﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
namespace Assets.Scripts
{
    public interface IVibratable : IGetPosition2D, ISetPosition2D
    {

    }
}